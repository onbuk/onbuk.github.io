# Offline-HTML-Games
Offliine(Local) HTML Tools/games most in only one html file that can be opened directly through the browser with no Webserver needed WHAT SO EVER!

# Credits (WIP!)
As you have most likely figured out almost none of these tools/games are made by me; I only compacted them to one file minimized them and uploaded them here, below is the list of github projects i used to make this respitory if your project is included but not mentioned or you would like it removed please feel free to create a new issue!

Projects used

[oldj/html5 tower defense](https://github.com/oldj/html5-tower-defense)

[Dystopia user181/connect pipes polygonal](https://github.com/Dystopia-user181/connect-pipes-polygonal)

[Metroxe/one html page challenge](https://github.com/Metroxe/one-html-page-challenge)

[orteil/musicgen](https://orteil.dashnet.org/musicgen)
